import { Component, OnInit } from '@angular/core';
import data from '../data/mobile.json';

@Component({
  selector: 'app-mobile',
  templateUrl: './mobile.component.html',
  styleUrls: ['./mobile.component.css']
})
export class MobileComponent implements OnInit {

  mobile=data
  constructor() { }

  ngOnInit() {
  }
sortId(){
this.mobile.sort((a,b) => (a.mobileId > b.mobileId) ? 1:-1)

}
sortName(){
  this.mobile.sort((a,b) => (a.mobileName > b.mobileName) ? 1:-1)
  
  }
  sortPrice(){
    this.mobile.sort((a,b) => (a.mobilePrice > b.mobilePrice) ? 1:-1)
    
    }
    DeleteData(i)
    {
      data.splice(i,1)
    }
  }
      
    
