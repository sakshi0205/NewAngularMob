import { async, ComponentFixture, TestBed } from '@angular/core/testing';

import { ShowmobileComponent } from './showmobile.component';

describe('ShowmobileComponent', () => {
  let component: ShowmobileComponent;
  let fixture: ComponentFixture<ShowmobileComponent>;

  beforeEach(async(() => {
    TestBed.configureTestingModule({
      declarations: [ ShowmobileComponent ]
    })
    .compileComponents();
  }));

  beforeEach(() => {
    fixture = TestBed.createComponent(ShowmobileComponent);
    component = fixture.componentInstance;
    fixture.detectChanges();
  });

  it('should create', () => {
    expect(component).toBeTruthy();
  });
});
