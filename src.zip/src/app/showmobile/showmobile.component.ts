import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-showmobile',
  templateUrl: './showmobile.component.html',
  styleUrls: ['./showmobile.component.css']
})
export class ShowmobileComponent implements OnInit {

  constructor() { }

  ngOnInit() {
  }

}
